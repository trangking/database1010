// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyA6WsKWXtI3OxRQwdgH7O8pjAqYLvUs21s",
  authDomain: "palita242-a91aa.firebaseapp.com",
  projectId: "palita242-a91aa",
  storageBucket: "palita242-a91aa.appspot.com",
  messagingSenderId: "768080587670",
  appId: "1:768080587670:web:31ff2cfdc535d16f154bb7",
  measurementId: "G-GGGWQ77WFE",
});

const db = getFirestore(firebaseApp);
export default db;
